(function(window, document, exportName, undefined) {
  'use strict';
